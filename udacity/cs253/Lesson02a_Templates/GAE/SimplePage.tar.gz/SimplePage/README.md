# App Engine Standard Flask Hello World

[![Open in Cloud Shell][shell_img]][shell_link]

[shell_img]: http://gstatic.com/cloudssh/images/open-btn.png
[shell_link]: https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/GoogleCloudPlatform/python-docs-samples&page=editor&open_in_editor=appengine/standard/flask/hello_world/README.md

This sample shows how to use [Flask](http://flask.pocoo.org/) with Google App
Engine Standard.

For more information, see the [App Engine Standard README](../../README.md)

# GAE使用的是python2.7