# Copyright 2016 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# [START app]

#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
from flask import Flask, request, redirect, url_for
import CheckDate, Form

app = Flask(__name__)

@app.route('/', methods=['GET'])
def get():
	return Form.make_form()

@app.route('/', methods=['POST'])
def post():
	us_month = request.form['month']
	us_day = request.form['day']
	us_year = request.form['year']

	s_month = CheckDate.valid_month(us_month)
	s_day = CheckDate.valid_day(us_day)
	s_year = CheckDate.valid_year(us_year)

	if not ( s_month and s_day and s_year ):
		return Form.make_form(error='Invalid Date', month=us_month, day=us_day, year=us_year)
	else:
		return redirect(url_for('SuccessLoginHandler'))

@app.route('/WelcomePage')
def SuccessLoginHandler():
	return "<div style=\"color: red\">Welcome!</div>"

# if __name__ == '__main__':
# 	app.run(port=8000, debug=True)

@app.errorhandler(500)
def server_error(e):
    # Log the error and stacktrace.
    logging.exception('An error occurred during a request.')
    return 'An internal error occurred.', 500
# [END app]
